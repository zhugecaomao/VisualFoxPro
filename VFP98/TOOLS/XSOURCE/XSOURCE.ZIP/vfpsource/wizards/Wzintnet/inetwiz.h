#DEFINE C_DEBUG	.F.

***** Dropdown list selector
#DEFINE STEP1_LOC	"Step 1 - Select Table"
#DEFINE STEP2_LOC	"Step 2 - Choose Search Field"
#DEFINE STEP3_LOC	"Step 3 - Set Search Page Options"
#DEFINE STEP4_LOC	"Step 4 - Set Up Search Page"
#DEFINE STEP5_LOC	"Step 5 - Select Result Fields"
#DEFINE STEP6_LOC	"Step 6 - Set Up Result Page"
#DEFINE STEP7_LOC	"Step 7 - Finish"

***** Screen directions
#DEFINE DESC0_LOC	"The wizard helps you create a Web page that searches your "+ ;
					"data.  The data must be Visual FoxPro 3.0 or later."

#DEFINE DESC1a_LOC	"Which table do you want the Web page to search?"
#DEFINE	DESC1b_LOC	"Select a database or Free Tables, and then select "+ ;
					"a table from the list."
#DEFINE DESC1		DESC1a_LOC+CRET+CRET+DESC1b_LOC

#DEFINE DESC2a_LOC	"Which index of the table do you want the Web page to search?"
#DEFINE	DESC2b_LOC	"You can search on any indexed field in the selected table."
#DEFINE DESC2		DESC2a_LOC+CRET+CRET+DESC2b_LOC

#DEFINE DESC3a_LOC	"What text do you want displayed on the Web search page?"
#DEFINE	DESC3b_LOC	"Enter text for the title and description of the search page. "+ ;
					"The description will appear just below the title."
#DEFINE DESC3		DESC3a_LOC+CRET+CRET+DESC3b_LOC

#DEFINE DESC4a_LOC	"Do you want to include a background or header image on the "+ ;
					"Web search page?"
#DEFINE DESC4b_LOC	"You may select any JPEG or GIF file. "
#DEFINE DESC4c_LOC	"You can also provide an option to return the search results as a file."
#DEFINE DESC4		DESC4a_LOC+CRET+CRET+DESC4b_LOC+DESC4c_LOC

#DEFINE DESC5a_LOC	"Which fields do you want to return from the search?"
#DEFINE	DESC5b_LOC	"You can return up to 5 fields from the selected table."
#DEFINE DESC5		DESC5a_LOC+CRET+CRET+DESC5b_LOC

#DEFINE DESC6a_LOC	"Do you want to include a background or header image on the Web "+ ;
					"result page?"
#DEFINE DESC6b_LOC	"You may select any JPEG or GIF file. "
#DEFINE DESC6c_LOC	"You can also set the maximum number of records that will be "+ ;
					"returned by the search and a data source for the Microsoft Internet Information Server."
#DEFINE DESC6		DESC6a_LOC+CRET+CRET+DESC6b_LOC+DESC6c_LOC

#DEFINE DESC7		""	&&empty--finish screen

***** Screen BMP files
#DEFINE BMPFILE1	"bmps\tablesel.bmp"
#DEFINE BMPFILE2	"bmps\srchfld.bmp"
#DEFINE BMPFILE3	"bmps\srchpage.bmp"
#DEFINE BMPFILE4	"bmps\srchpict.bmp"
#DEFINE BMPFILE5	"bmps\retfield.bmp"
#DEFINE BMPFILE6	"bmps\retpict.bmp"
#DEFINE BMPFILE7	""

#DEFINE	E_BADPARMS_LOC	"Invalid parameters passed."

** Data types
#DEFINE DT_NUMERIC  'N'
#DEFINE DT_FLOAT 	'F'
#DEFINE DT_LOGIC 	'L'
#DEFINE DT_MEMO  	'M'
#DEFINE DT_GENERAL  'G'
#DEFINE DT_CHAR  	'C'
#DEFINE DT_DATE  	'D'
#DEFINE DT_DOUBLE  	'B'
#DEFINE DT_TIME  	'T'
#DEFINE DT_MONEY  	'Y'

** Miscellaneous
#DEFINE NUM_AFIELDS		11	&&linear dimension of AFIELDS
#DEFINE C_SEP			" = "			&&property separator
#DEFINE C_VERSTAMP		"VERSION =  0.007"
#DEFINE C_DOS     		"DOS"
#DEFINE C_WINDOWS 		"WINDOWS"
#DEFINE C_MAC     		"MAC"
#DEFINE C_UNIX    		"UNIX"
#DEFINE	C_CRLF			CHR(13)+CHR(10)	&&return/linefeed
#DEFINE	C_CR			CHR(13)			&&return
#DEFINE	C_LF			CHR(10)			&&linefeed
#DEFINE	C_TAB			CHR(9)			&&tab
#DEFINE	C_SCXEXT		"SCX"			&&2.x screen extension
#DEFINE C_DEFSET		"Formset1"
#DEFINE C_DEFFORM		"Form1"
#DEFINE C_MAXCHAR		60
#DEFINE C_WINFONT		"MS Sans Serif"
#DEFINE C_WINFSIZE		8
#DEFINE C_WINFSTYLE		"B"
#DEFINE C_WINFBOLD		.T.
#DEFINE C_WINFITALIC	.F.
#DEFINE C_WINFUNDER		.F.
#DEFINE CRET			CHR(13)
#DEFINE CRLF			CHR(13)+CHR(10)


* Error messages used to check for valid styles.

#DEFINE WZ_DIRNAME	'WIZARDS\WIZBMPS'		&&dirname for bmps
#DEFINE WIZ_DIR		'WIZARDS\'				&&default wizard directory --relative to SYS(2004)
#DEFINE WIZ_STYDBF	'FRMSTYLE.DBF'			&&wizard style dbf
#DEFINE WIZ_STYVCX	'WIZSTYLE.VCX'			&&wizard style class lib
#DEFINE C_LOCATE_LOC	'Locate: '			&&GetFile prompt -- note keep it small so file fits

#DEFINE ERR_FORMSET_LOC	"Formsets are not supported as styles in the Form Wizard."

* Registry constants
#DEFINE ERROR_SUCCESS	0			&& all is fine
#DEFINE C_RESWIDTH		"ResWidth"	&& Options dialog setting
#DEFINE C_RESHEIGHT		"ResHeight"	&& Options dialog setting

* File Saving Strings
#DEFINE	C_HTMLMSG_LOC	"HTML file:"
#DEFINE C_HEADERIMG_LOC	"GIF/JPG file:"
#DEFINE	C_BKGDIMG_LOC	"GIF/JPG file:"

#DEFINE	wizInternet_Wizard_Step_1	1999965411
#DEFINE	wizInternet_Wizard_Step_2	1999965412
#DEFINE	wizInternet_Wizard_Step_3	1999965413
#DEFINE	wizInternet_Wizard_Step_4	1999965414
#DEFINE	wizInternet_Wizard_Step_5	1999965415
#DEFINE	wizInternet_Wizard_Step_6	1999965416
#DEFINE	wizInternet_Wizard_Step_7	1999965417

#DEFINE	TITLE1_LOC			"Visual FoxPro HTML Search Page"
#DEFINE	TITLE2_LOC			"Visual FoxPro Query Return Page"
#DEFINE	STRINGHERE_LOC		"Enter your search string here:"
#DEFINE	SEARCHBTNCAPTION_LOC	"Search"
#DEFINE	RETDATA_LOC		"Return data as file."
#DEFINE	GENERATE_LOC		'Generated by the Visual FoxPro WWW Search Page Wizard<br>'