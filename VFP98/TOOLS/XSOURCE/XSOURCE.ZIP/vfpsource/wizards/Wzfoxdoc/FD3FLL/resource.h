//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by fd3.rc
//
#define IDS_STRING1                     1
#define IDS_ABORT                       1
#define IDS_ADDINGFILE                  2
#define IDS_LINE_TOKEN                  3
#define IDS_PASSSTR                     4
#define IDS_PASSLINE                    5
#define IDS_ADDING                      6
#define IDS_ERROR_SCX                   7
#define IDS_PROCEDURE                   8
#define IDS_FORMAT                      9
#define IDS_LIBRARY                    10
#define IDS_HELP                       11
#define IDS_RESOURCE                   12
#define IDS_PRINTER                    13
#define IDS_ALTERNATE                  14


#define IDS_INDEX                      15
#define IDS_CLASSLIBRARY               16
#define IDS_EXTERNALS                  17
#define IDS_ILLEGAL_TOP                18
#define IDS_INDEXING                   19
#define IDS_DONE                       20
#define IDS_THERMUP                    21



// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
